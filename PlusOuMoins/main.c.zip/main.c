//
//  main.c
//  PlusOuMoins
//
//  Created by Heric Vignola on 25/09/2014.
//  Copyright (c) 2014 Heric Vignola. All rights reserved.
//

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main ( int argc, char** argv )
{
    int continuerPartie = 1;


    // On lance la boucle tant que la variable continuerPartie ne passe pas a 0
    while (continuerPartie != 0) {
        
        continuerPartie = 1;    //On reinitialise la variable continuerPartie pour le prochain loop.
        
        int reponseJoueurContinuerPartie = 0;
        int difficulte = 0;
        int nombreMystere = 0, nombreEntre = 0, nombreCoups = 0;
        int MAX = 0;
        const int MIN = 1;
        
        
        
        //Selection de la difficulté
        while (difficulte != 1 && difficulte != 2 && difficulte != 3) {
            printf("En quel difficulté voulez-vous jouer?\n");
            printf("1. Facile\n");
            printf("2. Moyen\n");
            printf("3. Difficile\n");
            printf("Votre réponse -> ");
            scanf("%d", &difficulte);
            
            switch (difficulte) {
                case 1:
                    MAX = 100;
                    printf("\n\n");
                    break;
                case 2:
                    MAX = 1000;
                    printf("\n\n");
                    break;
                case 3:
                    MAX = 10000;
                    printf("\n\n");
                    break;
                default:
                    printf("Cette reponse n'est pas valide.\n\n");
                    break;
            }
        
        }
        
        
        
        // Génération du nombre aléatoire
        srand(time(NULL));
        nombreMystere = (rand() % (MAX - MIN + 1)) + MIN;
        
        
        
        // La boucle du programme. Elle se répète tant que l'utilisateur n'a pas trouvé le nombre mystère
        do
        {
            // On ajoute un coup a chaque passage dans la boucle
            nombreCoups++;
            // On demande le nombre
            printf("Quel est le nombre %d ? ",nombreMystere);
            scanf("%d", &nombreEntre);
            
            // On compare le nombre entré avec le nombre mystère
            
            if (nombreMystere > nombreEntre)
                printf("C'est plus !\n\n");
            else if (nombreMystere < nombreEntre)
                printf("C'est moins !\n\n");
            else
                printf ("Bravo, vous avez trouve le nombre mystere en %d coups !!!\n\n", nombreCoups);
        } while (nombreEntre != nombreMystere);
     
        
        
        // On demande au joueur s'il veut faire une autre partie
        while (reponseJoueurContinuerPartie != 1 && reponseJoueurContinuerPartie != 2) {
            printf("Voulez vous faire une autre partie ?\n");
            printf("1. oui\n");
            printf("2. non\n");
            printf("Votre réponse -> ");
    
            scanf("%d",&reponseJoueurContinuerPartie);
    
            switch (reponseJoueurContinuerPartie) {
                case 1:
                    printf("\n\n");
                    break;
                case 2:
                    continuerPartie = 0;
                    break;
                default:
                    printf("Cette reponse n'est pas valide\n\n");
                    break;
                }
            }
        
    }
    
}